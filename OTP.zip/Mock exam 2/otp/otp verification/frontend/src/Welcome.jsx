import React from 'react';

function Welcome() {
  return <h1>Welcome to the Application!</h1>;
}

export default Welcome;
